%Bee-Live 1.0
%---------------------
%
%This Softaware was developed by
%Gean.R for the website Bee-Live free softwares based on GNU Octave.
%
%
%
%How to Use
%---------------------
%When you upload the Video file make sure that this one
%are in WMV format or otherwise it won't work
%
%After run the code on the editor or calling on the Command
%window by his name (Video_to_MP3_Converter)...check it this same window
%and press y to start to convert.
%Now go to the path given by the output. There will be the file

%---------------------
