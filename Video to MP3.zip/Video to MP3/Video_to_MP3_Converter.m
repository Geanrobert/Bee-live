function wmv_to_mp3_converter_gui()
    % Create a figure (window)
    fig = figure('Name', 'WMV to MP3 Converter', 'Position', [500, 300, 400, 200]);

    % File selection button
    uicontrol(fig, 'Style', 'pushbutton', 'String', 'Select WMV File', ...
              'Position', [50, 140, 300, 40], ...
              'Callback', @select_file);

    % Conversion button
    uicontrol(fig, 'Style', 'pushbutton', 'String', 'Convert to MP3', ...
              'Position', [50, 80, 300, 40], ...
              'Callback', @convert_to_mp3);

    % Output message
    global msg;
    msg = uicontrol(fig, 'Style', 'text', 'String', 'Select a file to convert.', ...
                    'Position', [50, 30, 300, 30]);

    global wmv_file;
    global output_folder;
    wmv_file = '';
    output_folder = 'C:\Users\User\Music'; % Default output folder

end

function select_file(~, ~)
    global wmv_file;
    global msg;
    [filename, pathname] = uigetfile({'*.wmv'}, 'Select WMV File');
    if filename ~= 0
        wmv_file = fullfile(pathname, filename);
        set(msg, 'String', ['Selected: ', filename]);
    else
        set(msg, 'String', 'No file selected.');
    end
end

function convert_to_mp3(~, ~)
    global wmv_file;
    global output_folder;
    global msg;

    if isempty(wmv_file)
        set(msg, 'String', 'Please select a file first!');
        return;
    end

    [~, name, ~] = fileparts(wmv_file);
    mp3_file = fullfile(output_folder, strcat(name, '.mp3'));

    command = strcat('ffmpeg -i "', wmv_file, '" -q:a 0 -map a "', mp3_file, '"');
    system(command);

    set(msg, 'String', ['Conversion complete! Saved in: ', mp3_file]);
end

% Run the GUI
wmv_to_mp3_converter_gui();

pause();
